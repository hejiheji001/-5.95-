function getJwtToken() {
    let token;
    Java.perform(function() {
        let ServiceManager = Java.use("com.shizhuang.duapp.modules.router.ServiceManager");
        token = ServiceManager.d().getJwtToken();
    });
    return token;
}


function getSK() {
    let SK;
    Java.perform(function() {
        let SZStone = Java.use("com.shizhuang.stone.SZStone");
        let context = Java.use("android.app.ActivityThread").currentApplication().getApplicationContext();
        SK = SZStone.getStoneSync(context);
    });
    return SK;
}


//timestamp like 1675436909169
function getTimestamp() {
    let timestamp;
    Java.perform(function() {
        let System = Java.use("java.lang.System");
        timestamp = System.currentTimeMillis();
    });
    return timestamp;
}

function mapToString(map) {
    let mapString = "";
    Java.perform(function () {
        let RequestUtils = Java.use("jf.j0");
        mapString = RequestUtils.g(map);
    });
    return mapString;
}

//搜索数据
Java.perform(function () {
    let SearchProductResultViewModel = Java.use("com.shizhuang.duapp.modules.mall_search.search.newversion.vm.SearchProductResultViewModel");
    SearchProductResultViewModel["f"].implementation = function (searchMallProductModel, z) {
        console.log('f is called' + ', ' + 'searchMallProductModel: ' + searchMallProductModel + ', ' + 'z: ' + z);
        let ret = this.f(searchMallProductModel, z);
        console.log('f ret value is ' + ret);
        return ret;
    };
});

Java.perform(function () {
    let Builder = Java.use("okhttp3.Headers$Builder");
    Builder["add"].overload('java.lang.String', 'java.lang.String').implementation = function (str, str2) {
        // console.log('add is called' + ', ' + 'str: ' + str + ', ' + 'str2: ' + str2);

        if (str === 'skc') {
            console.log("skc:" + str2);
        }

        if (str === 'sk') {
            console.log("SK:" + str2);
        }

        if (str === 'X-Auth-Token') {
            console.log("X-Auth-Token:" + str2);
        }

        if (str === 'x-dus-token') {
            console.log("x-dus-token:" + str2);
        }

        let ret = this.add(str, str2);
        // console.log('add ret value is ' + ret);
        return ret;
    };
} );

//推荐数据
Java.perform(function () {
    let HomeComponentNewEngine = Java.use("lt0.a");
    HomeComponentNewEngine["d"].implementation = function (str, z, str2) {
        console.log('d is called' + ', ' + 'str: ' + str + ', ' + 'z: ' + z + ', ' + 'str2: ' + str2);
        let ret = this.d(str, z, str2);
        console.log('d ret value is ' + ret);

        Java.perform(function() {
            var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
            console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
        });

        return ret;
    };
});



function getDusTokenTest() {
    let dusToken;
    Java.perform(function() {

        let TreeMap = Java.use("java.util.TreeMap");
        let map = TreeMap.$new();

        map.put("abTest", '{"name":"Commodity_subject","value":"2"},{"name":"Commodity_chuanda","value":"1"},{"name":"476_yxtag","value":"2"},{"name":"recommend_line","value":"0"},{"name":"487_syyc","value":"0"},{"name":"480_xinpinab","value":"2"},{"name":"V4925_feeds_banner","value":"0"},{"name":"V496_jingangwei_icon","value":"0"},{"name":"categoryAB","value":"1"},{"name":"495_qtbq","value":"2"},{"name":"500_qtbq","value":"0"},{"name":"v500_shouye_pd","value":"1"},{"name":"shouye_search_opt","value":"2"},{"name":"530_dtpx","value":"2"},{"name":"495_pblcard","value":"1"},{"name":"510_hxdjsp","value":"0"},{"name":"550_dcbq","value":"1"},{"name":"560_xrzk","value":"1"},{"name":"V570_feeds_banner_shijue","value":"0"},{"name":"570_tjyhj","value":"1"},{"name":"V580_xinren_coupon","value":"0"},{"name":"580_qtbx","value":"0"},{"name":"509_ppzgab","value":"0"},{"name":"590_qwdj","value":"0"}');
        map.put("extMap", '{"goodAdvCount":0}');
        map.put("homeVersion", "1");
        map.put("isHideModel", "false");
        map.put("lastBrandingId", "44");
        map.put("lastId", "4");
        map.put("limit", "20");
        map.put("loginToken", "");
        map.put("newSign", "63c5849cadde807c23cbbd76bfcb7a53");
        map.put("newbieType", "0");
        map.put("platform", "android");
        map.put("refreshFlag", "false");
        map.put("timestamp", "1675546314075");
        map.put("v", "5.9.5");

        let PostJsonBody = Java.use("xd.g").$new(map);
        // let tree = Java.cast(PostJsonBody, Java.use("xd.g"))._b.value;
        let RequestUtils = Java.use("jf.j0");
        dusToken = RequestUtils.e(PostJsonBody, map, 1675546314075, false);
    });
    return dusToken;
}

function getDusToken(map, timestamp) {
    let dusToken;
    Java.perform(function() {
        let PostJsonBody = Java.use("xd.g").$new(map);
        let RequestUtils = Java.use("jf.j0");
        dusToken = RequestUtils.e(PostJsonBody, map, timestamp, false);
    });
    return dusToken;
}

//find where is "newSign" in the request
Java.perform(function() {
    // let ParamsBuilder = Java.use("com.shizhuang.duapp.common.helper.net.ParamsBuilder");
    // ParamsBuilder["newParams"].overload('java.util.Map').implementation = function (map) {
    //     let ret = this.newParams(map);
        // if(str === "skc") {
        //     console.log('addParams: skc ' + str + ', ' + '\r\nobj: ' + obj);
        //     let ret = this.addParams(str, obj);
        //     console.log('addParams ret value is ' + ret);
        //     console.log('Stack trace: ');
        //     Java.perform(function() {
        //         var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
        //         console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
        //     });
        // }

    //     iterthru(map);
    //     console.log(ret);
    //     return ret;
    // };

    //
    // let Builder = Java.use("okhttp3.Request$Builder");
    // Builder["addHeader"].implementation = function (str, str2) {
    //     let ret = this.addHeader(str, str2);
    //     if (str === 'skc') {
    //         console.log('addHeader is called\r\n' + ', ' + 'str: ' + str + '\r\n ' + 'str2: ' + str2 + '\r\naddHeader ret value is ' + ret);
    //         Java.perform(function() {
    //             var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
    //             console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
    //         });
    //     }
    //     return ret;
    // };

    //
    let Builder = Java.use("okhttp3.Headers$Builder");
    Builder["add"].overload('java.lang.String', 'java.lang.String').implementation = function (str, str2) {
        // console.log('add is called' + ', ' + 'str: ' + str + ', ' + 'str2: ' + str2);

        if (str === 'skc') {
            // Java.perform(function() {
            //     var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
            //     console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
            // });
            // console.log(str2);
            // str2 = "CUEKWugRdiCuGRdceF166l7Vt3LR6796";
            console.log(str2);
        }

        let ret = this.add(str, str2);
        // console.log('add ret value is ' + ret);
        return ret;
    };
});

function getNewSignTest ()  {
    let newSign;
    Java.perform(function() {
        let str = 'abTest{"name":"Commodity_subject","value":"2"},{"name":"Commodity_chuanda","value":"1"},{"name":"476_yxtag","value":"2"},{"name":"recommend_line","value":"0"},{"name":"487_syyc","value":"0"},{"name":"480_xinpinab","value":"2"},{"name":"V4925_feeds_banner","value":"0"},{"name":"V496_jingangwei_icon","value":"0"},{"name":"categoryAB","value":"1"},{"name":"495_qtbq","value":"2"},{"name":"500_qtbq","value":"0"},{"name":"v500_shouye_pd","value":"1"},{"name":"shouye_search_opt","value":"2"},{"name":"530_dtpx","value":"2"},{"name":"495_pblcard","value":"1"},{"name":"510_hxdjsp","value":"0"},{"name":"550_dcbq","value":"1"},{"name":"560_xrzk","value":"1"},{"name":"V570_feeds_banner_shijue","value":"0"},{"name":"570_tjyhj","value":"1"},{"name":"V580_xinren_coupon","value":"0"},{"name":"580_qtbx","value":"0"},{"name":"509_ppzgab","value":"0"},{"name":"590_qwdj","value":"0"}'+
            'extMap{"goodAdvCount":0}homeVersion1isHideModelfalselastBrandingId63lastId2limit20'+
            'loginTokennewbieType0platformandroidrefreshFlagfalse'+
            'timestamp1675548281387uuid1111111111110000v5.9.5';

        let AESEncrypt = Java.use("com.duapp.aesjni.AESEncrypt");
        let DuHttpConfig = Java.use("ne.a");
        obj = DuHttpConfig.d.value;
        let encode = AESEncrypt.encode(obj, str);
        let RequestUtils = Java.use("jf.j0");
        newSign = RequestUtils.f(encode); //bfedbc5badf512329c73c2295763260a

        let TreeMap = Java.use("java.util.TreeMap");
        let map = TreeMap.$new();
        map.put("abTest", '{"name":"Commodity_subject","value":"2"},{"name":"Commodity_chuanda","value":"1"},{"name":"476_yxtag","value":"2"},{"name":"recommend_line","value":"0"},{"name":"487_syyc","value":"0"},{"name":"480_xinpinab","value":"2"},{"name":"V4925_feeds_banner","value":"0"},{"name":"V496_jingangwei_icon","value":"0"},{"name":"categoryAB","value":"1"},{"name":"495_qtbq","value":"2"},{"name":"500_qtbq","value":"0"},{"name":"v500_shouye_pd","value":"1"},{"name":"shouye_search_opt","value":"2"},{"name":"530_dtpx","value":"2"},{"name":"495_pblcard","value":"1"},{"name":"510_hxdjsp","value":"0"},{"name":"550_dcbq","value":"1"},{"name":"560_xrzk","value":"1"},{"name":"V570_feeds_banner_shijue","value":"0"},{"name":"570_tjyhj","value":"1"},{"name":"V580_xinren_coupon","value":"0"},{"name":"580_qtbx","value":"0"},{"name":"509_ppzgab","value":"0"},{"name":"590_qwdj","value":"0"}');
        map.put("homeVersion", "1");
        map.put("extMap", '{"goodAdvCount":0}');
        map.put("limit", "20");
        map.put("refreshFlag", "false");
        map.put("lastBrandingId", "63");
        map.put("lastId", "2");
        map.put("isHideModel", "false");
        map.put("newbieType", "0");

        let sign2 = getNewSign(map, 1675548281387);
        console.log(newSign, sign2);

        map.put("newSign", newSign);
        map.put("loginToken", "");
        map.put("v", "5.9.5");
        map.put("platform", "android");
        map.put("timestamp", 1675548281387 + '');

        let dusToken = getDusToken(map, 1675548281387); //1675548281387;CEkXfvWky6NhBEDTcUEUohOf9AOZ
        console.log(dusToken, '1675548281387;CEkXfvWky6NhBEDTcUEUohOf9AOZ');

    });
    return newSign;
}

Java.perform(function() {
    let RequestUtils = Java.use("jf.j0");
    // RequestUtils["b"].implementation = function (map, j, str) {
    //     // j = 1675439208455;
    //
    //     // map.remove("extMap");
    //     // map.remove("abTest");
    //     // map.remove("lastBrandingId");
    //     // map.remove("lastId");
    //     // map.put("lastId", "4");
    //     // map.put("lastBrandingId", "44");
    //     // map.put("abTest", '{"name":"Commodity_subject","value":"2"},{"name":"Commodity_chuanda","value":"1"},{"name":"476_yxtag","value":"2"},{"name":"recommend_line","value":"0"},{"name":"487_syyc","value":"0"},{"name":"480_xinpinab","value":"2"},{"name":"V4925_feeds_banner","value":"0"},{"name":"V496_jingangwei_icon","value":"0"},{"name":"categoryAB","value":"1"},{"name":"495_qtbq","value":"2"},{"name":"500_qtbq","value":"0"},{"name":"v500_shouye_pd","value":"1"},{"name":"shouye_search_opt","value":"2"},{"name":"530_dtpx","value":"2"},{"name":"495_pblcard","value":"1"},{"name":"510_hxdjsp","value":"0"},{"name":"550_dcbq","value":"1"},{"name":"560_xrzk","value":"1"},{"name":"V570_feeds_banner_shijue","value":"0"},{"name":"570_tjyhj","value":"1"},{"name":"V580_xinren_coupon","value":"0"},{"name":"580_qtbx","value":"0"},{"name":"509_ppzgab","value":"0"},{"name":"590_qwdj","value":"0"}');
    //     // map.put("extMap", '{"goodAdvCount":0}');
    //     console.log('newSign map ++++++++++');
    //     iterthru(map);
    //
    //     let ret = this.b(map, j, str);
    //
    //     // console.log(this.g(map));
    //
    //     console.log('newSign ++++++++++++++' + ret);
    //     return ret;
    // };

    RequestUtils["e"].implementation = function (requestBody, map, j, z) {
        // console.log('e is called' + ', ' + 'requestBody: ' + requestBody + ', ' + 'map: ' + map + ', ' + 'j: ' + j + ', ' + 'z: ' + z);
        console.log("map: ++++++++++++");
        console.log(this.g(map));
        iterthru(map);
        let ret = this.e(requestBody, map, j, z);
        let tree = Java.cast(requestBody, Java.use("xd.g"))._b.value;
        console.log("body============");
        iterthruTree(tree);

        map.remove("abTest");
        map.put("abTest", createAbtest());

        let dus = getDusToken(map, j);
        console.log("end++++++++++++" + ret, dus);
        return ret;
    };
});

Java.perform(function() {
    let AbstractC27535m = Java.use("ne.a$m");
    AbstractC27535m["getShieldId"].implementation = function (map, j) {
        console.log('getShieldId is called' + ', ' + 'map: ' + map + ', ' + 'j: ' + j);
        iterthru(map);
        let ret = this.getShieldId(map, j);
        console.log('getShieldId ret value is ' + ret);
        return ret;
    };
});

Java.perform(function() {
    let Builder = Java.use("okhttp3.Headers$Builder");
    Builder["add"].overload('java.lang.String', 'java.lang.String').implementation = function (str, str2) {
        let ret = this.add(str, str2);
        if (str === 'skc') {
            console.log('add is called' + ', ' + 'str: ' + str + ', ' + 'str2: ' + str2);
            // Java.perform(function() {
            //     var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
            //     console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
            // });
            console.log('add ret value is ' + ret);
        }
        return ret;
    };
});



Java.perform(function() {
    let ObserveOnObserver = Java.use("io.reactivex.internal.operators.observable.ObservableObserveOn$ObserveOnObserver");
    ObserveOnObserver["drainNormal"].implementation = function () {
        console.log('drainNormal is called');
        console.log(JSON.stringify(this.queue));
        console.log(JSON.stringify(this.downstream));

        let ret = this.drainNormal();
        console.log('drainNormal ret value is ' + ret);
        return ret;
    };
});

//create a hashmap using frida
function getNewSign (map, timestamp)  {
    let newSign;
    Java.perform(function() {
        let RequestUtils = Java.use("jf.j0");
        newSign = RequestUtils.b(map, timestamp, "");
    });
    return newSign;
}

function getSKC (){
    let skc;
    Java.perform(function() {
        skc = Java.use("com.shizhuang.dusanwa.Il11IIl1lll").ll1lIll1II11();
    });
    return skc;
}

function createAbtest() {
    let abtest;
    let result;
    Java.perform(function() {
        let C29451b = Java.use("st0.b").$new();
        abtest = C29451b.a();
        let CollectionsKt__CollectionsKt = Java.use("kotlin.collections.CollectionsKt__CollectionsKt").mutableListOf(abtest);
        result = Java.cast(CollectionsKt__CollectionsKt, Java.use("java.lang.Object"));
    });

    return result;
}

function getAllParamsForShoppingList() {
    Java.perform(function() {
        let jwtToken = getJwtToken();
        let sk = getSK();
        let time = getTimestamp();
        let skc = getSKC();

        let TreeMap = Java.use("java.util.TreeMap");
        let map = TreeMap.$new();

        time = 1675439208455;
        map.put("abTest", createAbtest());

        let newExtMap = Java.use("java.util.Collections").singletonMap("goodAdvCount", "0");
        map.put("extMap", newExtMap);
        map.put("homeVersion", "1");
        map.put("isHideModel", "false");
        map.put("lastBrandingId", "44");
        map.put("lastId", "4");
        map.put("limit", "20");
        map.put("newbieType", "0");
        map.put("refreshFlag", "false");

        // let RequestUtils = Java.use("jf.j0");
        // let s = RequestUtils.g(map);
        console.log("============");
        let newSign = getNewSign(map, time);
        map.put("newSign", newSign);
        map.put("loginToken", "");
        map.put("timestamp", time + '');
        map.put("v", "5.9.5");
        map.put("platform", "android");

        let dusToken = getDusToken(map, time);

        let result = "timestamp:"+time+"\r\nX-Auth-Token:"+jwtToken+"\r\nSK:"+sk+"\r\nx-dus-token:"+dusToken+"\r\nskc:"+skc+"\r\n\r\nnewSign:"+newSign;
        console.log(result);
        console.log("============");
    });
}


function iterthru(map) {
    var keys = map.keySet();
    var iterator = keys.iterator();
    while (iterator.hasNext()) {
        var k = iterator.next();
        console.log(k + " : " + map.get(k));
    }
}

function iterthruTree(map) {
    var iterator = map.entrySet().iterator();
    while (iterator.hasNext()) {
        let k = iterator.next();
        console.log(k);
    }
}

Java.perform(function () {
    let RequestUtils = Java.use("jf.j0");
    RequestUtils["e"].implementation = function (requestBody, map, j, z) {
        let ret = "1";
        try {
            let body = Java.cast(requestBody, Java.use("xd.g"));
            console.log(body._b.value);
            console.log("------");
            iterthru(map);
            console.log("------");
            console.log(j);
            console.log(z);
            ret = this.e(requestBody, map, j, z);
            console.log('e ret value is ' + ret);

            Java.perform(function() {
                var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
                console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
            });
        } catch (e)  {}
        return ret;
    };
});

Java.perform(function () {
    let RequestUtils = Java.use("jf.j0");
    RequestUtils["d"].implementation = function (map) {
        iterthru(map);
        console.log(j);
        console.log(str);
        let ret = this.d(map);
        console.log('d ret value is ' + ret);

        Java.perform(function() {
            var jAndroidLog = Java.use("android.util.Log"), jException = Java.use("java.lang.Exception");
            console.log( jAndroidLog.getStackTraceString( jException.$new() ) );
        });
        return ret;
    };
});

//MjgxMERBOUYyNEY2RjE3QTE1QjM5NUQ1Rjc5NjMxOUEuY0dGeVlXMGZZamxoWWprd01qY3RPVE5pWWkwME1EYzJMV0kzTnpVdE1UWTJORGhpWWpSbU16aGtIblpsY25OcGIyNGZNUjV3YkdGMFptOXliUjloYm1SeWIybGtIbVZqSHpFPS6Zu3TCsMDAJSArGOqEpCNbcnSWWXqJLJUsJmohpHYRRLVXhQmvPgsM2FusIZ72R0NtoyCUW-0Vjqvu-bDp755VPZeQ0-r1iGNIAtAA6DygcVa7Aj29t9jgSXNnjR_wSyNVjAD7qOv1sNhbrCGe9kdDdKsN8Qz17ulw4i92l_szncYvGGr5zrizYb8OfwAQnu5vwn9A9hhjnQpmXiK3I4Yohobyi2WIo8pp7JL2PbTXB6IS2TXTv7eHfvoQ3tJ7o2GGhvKLZYijyjYWu1AxBsuxohLZNdO_t4doCOMOH1Vq_YaG8otliKPKNha7UDEGy7GiEtk107-3h__fmWtpBAVVjaTb777rUacCaTN82X0r9FOESlXQTDFH8tC1XW0RraDe-8fd_JEWND2XkNPq9YhjSALQAOg8oHHXmaut82BM6p0rC1WuVu3QPZeQ0-r1iGOD_eYCOpgzz-3UXHdvbuidV3LQyZAiAUS_1slGg1IFc57PiXU1M4rjkWvjDkRdG6-sMzxK_1h9202HB2yrKAbZrxBmuq1JOoZd28rc-e3NoIzf6CbMrZUVwBRRZ_79n_tdXRbW0mK-heZ-gPB4aIrAMno_uGuRYQ51cfG_-bSSc-E5B6WKtaFWzGSPfTrTE3DKjrr-wv2mbuy9yMBJlR5JjoiqxF_GhtFn3QvFDW8DQs84H-oAo0C5mjmtLzX3Nr1Hl_NSyE13HoEc9UkSQBTweDQ792CTYKJoA9Cio4NbC4Nqw64WJqjNxoJk7qi328FE_LqrucNJa6zhUy3H_rktDw7g8clVqGMgdQcqAe7yi3Giogbo1ZkJfoT6LDVVAPsXkdHqSNrg6813v0tlFXyIYrNVRDMPuz68s37pfNEi_zrqY4X2Ma9u3tm5HjBb21PSrxNblbIuqQzTm8PP5v9Y47HRzKjtm3d_VfQByK2tbr01n3cGkbHzCsQ9xC7J3ztddxVYTUd_sL8IqkweCoZbVhJtITZiKyT25nW4wCxLkiGMEUd1aZeHGDjy0MKBQwmCQcu47T3NBGRhdk7iFMBds7NvRJPmFqv593UXBIB-1oCvt8VEmceMywCxRkhg1JsaVIHdcn1hCNgpbj1a90iR0FbIZn_JMHdP5nSX8MWEKw==
//
// function getNewSign(str) {
//     let newSign;
//     Java.perform(function() {
//         let RequestUtils = Java.use("jf.j0");
//         newSign = RequestUtils.f(str);
//     });
//     return newSign;
// }